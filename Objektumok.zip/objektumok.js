//1. feladat
let user = {};

//2. feladat
user.firstName = "John";
console.log(user);

//3. feladat
user.lastName = "Smith";
console.log(user);

//4. feladat
user.firstName = "Paul";
console.log(user);

//5. feladat
delete user.firstName
console.log(user);